public class Ponto {
    private double x, y;

    //Construtor
    public Ponto(double x, double y) {
        if (x >= 0 && y >= 0) {         // Verifica se ambas as coordenadas são positivas
            this.x = x;
            this.y = y;
        } else {
            System.out.println("iv");
            System.exit(0);        // Terminar com codigo zero
        }
    }

    // Funcao para calcular distancia entre pontos
    double dist(Ponto p) {

        double dx = x - p.getX();
        double dy = y - p.getY();
        return Math.sqrt(dx * dx + dy * dy);

    }

    private double getX() {
        return x;
    }

    private double getY() {
        return y;
    }
}
