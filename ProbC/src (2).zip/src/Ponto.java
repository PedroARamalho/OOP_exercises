public class Ponto {
    private double x, y;

    public Ponto(double x, double y){
        this.x = x;
        this.y = y;
    }

    double dist (Ponto that) {
        double dx = this.x - that.x;
        double dy = this.y - that.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
