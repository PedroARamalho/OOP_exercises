public class Path {
    private Ponto[] points;
    private int r;
    Path(int r) {
        this.r = r;
        points=new Ponto[r];
    }

    private int i = 0;
    void add(Ponto p){
        points[i++]=p;
    }

    double distance(){
        double result = 0;
        for(int i=1; i < this.r; i++)
            result += points[i-1].dist(points[i]);
        return result;
    }
}
