public class Ponto {
    private final double x, y;
    // Construtor
    public Ponto(double x, double y) {
            this.x = x;
            this.y = y;
    }
    // Funcao para fazer distancia de pontos
    double dist(Ponto p) {

        double dx = x - p.getX();
        double dy = y - p.getY();
        return Math.sqrt(dx * dx + dy * dy);

    }

    private double getX() {
        return x;
    }

    private double getY() {
        return y;
    }
}
