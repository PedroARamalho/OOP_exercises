import java.util.ArrayList;
import java.util.List;

/**
 * Represents a polygon defined by a list of points.
 * Adjusts also all the points with a tolerance of 10^-9
 * @author Jorge Silva a67427
 * @version 2.5 29/02/2024
 * @inv number of points must be greater than 2 at all times
 * @inv three consecutive points cant be collinear
 * @inv cant exist intersecting edges within the polygon
 */

public class Polygon {
    private final List<Point> points;
    private static final double tolerance = Math.pow(10,-9);

    /**
     * Constructs a polygon from a provided list of points.
     * @param points List of points that form the polygon.
     */
    public Polygon(List<Point> points) {
        if (points.size() < 3) {
            System.out.println("Poligono:vi");
            System.exit(0);
        }

        List<Point> adjustedPoints = new ArrayList<>();
        for (Point point : points) {
            adjustedPoints.add(new Point(point.getX() + tolerance, point.getY() + tolerance));
        }

        this.points = List.copyOf(adjustedPoints);
        validatePolygon();
    }

    /**
     * Validates the polygon by checking for collinear consecutive points or intersecting edges.
     */
    private void validatePolygon() {
        if (hasCollinearConsecutivePoints() || hasIntersectingEdges()) {
            System.out.println("Poligono:vi");
            System.exit(0);
        }
    }

    /**
     * Checks for any three consecutive points that are collinear.
     * @return true if any three consecutive points are collinear.
     */
    private boolean hasCollinearConsecutivePoints() {
        for (int i = 0; i < points.size(); i++) {
            Point p1 = points.get(i);
            Point p2 = points.get((i + 1) % points.size());
            Point p3 = points.get((i + 2) % points.size());

            if (new Straight(p1, p2, p3).areCollinear()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks for any intersecting edges within the polygon.
     * @return true if any pair of edges intersect.
     */
    private boolean hasIntersectingEdges() {
        for (int i = 0; i < points.size(); i++) {
            Straight_segment s1 = new Straight_segment(points.get(i), points.get((i + 1) % points.size()));
            for (int j = i + 2; j < points.size() + (i - 1) % points.size(); j++) {
                Straight_segment s2 = new Straight_segment(points.get(j % points.size()), points.get((j + 1) % points.size()));
                if (s1.doIntersect(s2)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Calculates and prints the perimeter of the polygon.
     * @return The perimeter of the polygon as an integer.
     */
    public void Perimeter() {
        double perimeter = 0;
        for (int i = 0; i < points.size(); i++) {
            perimeter += points.get(i).dist(points.get((i + 1) % points.size()));
        }
        System.out.println((int) perimeter);
    }

    public List<Point> getPoints() { return new ArrayList<>(points); }
}
