/**
 * Represents a straight defined by three points.
 * @author Jorge Silva a67427
 * @version 2.5 29/02/2024
 * @inv Points must form a straight line
 * @see www.youtube.com/watch?v=IBarBQ9klx4&ab_channel=AnilKumar"
 */

@SuppressWarnings("JavadocReference")
public class Straight {

    /**
     * Attributes
     */
    private Point p1;
    private Point p2;
    private Point p3;

    /**
     * Straight constructor
     * Checks if 3 points form a straight
     * Checks if the distance between 2 points is zero or <10^-9, if that's the case, we have a duplicated point.
     * @param p1 refers point 1
     * @param p2 refers point 2
     * @param p3 refers point 3
     */
    public Straight(Point p1, Point p2, Point p3){
        if(((Math.abs(p1.dist(p2)) < Math.pow(10,-9)) || ((Math.abs(p2.dist(p3)) < Math.pow(10,-9))))){
            System.out.println("Reta:vi");
            System.exit(0);
        }
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    /**
     * Check whether three points are collinear based on the slope
     * @return true if 3 points are collinear
     */
    public boolean areCollinear() {
        double slope0 = (p2.getY() - p1.getY()) / (p2.getX() - p1.getX());
        double slope1 = (p3.getY() - p1.getY()) / (p3.getX() - p1.getX());
        return Math.abs(slope0 - slope1) < Math.pow(10, -9);
    }
}
