/**
 * Defines a straight segment defined by two points
 * @author Jorge Silva a67427
 * @version 2.6 29/02/2024
 * @inv two segments may not intersect
 * @see www.geeksforgeeks.org/check-if-two-given-line-segments-intersect/
 */


@SuppressWarnings("JavadocReference")
public class Straight_segment {
    /**
     * Attributes
     */
    private final Point p1;
    private final Point p2;

    /**
     * Straight_segment constructor
     * Checks if p1 and p2 are not the same point
     * @param p1 refers point 1
     * @param p2 refers point 2
     */
    public Straight_segment(Point p1, Point p2) {
        if (Math.abs(p1.dist(p2)) < Math.pow(10,-9)) {
            System.out.println("Segmento:vi");
            System.exit(0);
        }
        this.p1 = p1;
        this.p2 = p2;
    }

    /**
     * Is true if point is on the segment
     * @param p1 refers point 1
     * @param p2 refers point 2
     * @param p3 refers point 3
     * @return true if the slope between p1 and p2 is the same for p1 and p3
     */
    private boolean onSegment(Point p1, Point p2, Point p3) {
        return new Straight(p1, p2, p3).areCollinear();
    }

    /**
     * Calculates an integer value for the orientation of a segment
     * @param p1 refers point 1
     * @param p2 refers point 2
     * @param p3 refers point 3
     * @return 0 if p1,p2 and p3 are collinear, 1 for Clockwise and 2 for Counterclockwise
     */
    private int orientation(Point p1, Point p2, Point p3) {
        double val=(p2.getY()-p1.getY())*(p3.getX()-p2.getX())-(p2.getX()-p1.getX())*(p3.getY()-p2.getY());
        if(val==0) return 0;
        return (val>0) ? 1:2;
    }

    /**
     *
     * @param other refers the other segment to check against
     * @return true if the segments intersect
     */
    public boolean doIntersect(Straight_segment other) {
        Point p3 = other.p1;
        Point p4 = other.p2;

        if (onSegment(p1, p3, p2) && !onSegment(p1, p4, p2)) return false;
        if (onSegment(p1, p4, p2) && !onSegment(p1, p3, p2)) return false;
        if (onSegment(p3, p1, p4) && !onSegment(p3, p2, p4)) return false;
        if (onSegment(p3, p2, p4) && !onSegment(p3, p1, p4)) return false;

        int o1=orientation(p1, p2, p3);
        int o2=orientation(p1, p2, p4);
        int o3=orientation(p3, p4, p1);
        int o4=orientation(p3, p4, p2);

        if (o1!=o2 && o3!=o4)
            return true;

        return false;
    }

}