import java.util.ArrayList;
import java.util.List;

/**
 * Represents a trajectory defined by a series of points.
 */
public class Trajectory {
    private List<Point> points = new ArrayList<>();

    /**
     * Adds a point to the trajectory.
     * @param point The point to be added to the trajectory.
     */
    public void add(Point point) {
        this.points.add(point);
    }

    /**
     * Checks if the trajectory intersects with any of the given obstacles (polygons).
     * @param obstacles A list of polygons representing the obstacles.
     * @return 1 if the trajectory intersects with any obstacle, 0 otherwise.
     */
    public int intersects(List<Polygon> obstacles) {
        // Iterate through each segment of the trajectory
        for (int i = 0; i < points.size() - 1; i++) {
            Point startTrajectory = points.get(i);
            Point endTrajectory = points.get(i + 1);
            System.out.println("Verifying trajectory segment: From " + startTrajectory.getX() + "," + startTrajectory.getY() + " to " + endTrajectory.getX() + "," + endTrajectory.getY());

            Straight_segment trajectorySegment = new Straight_segment(startTrajectory, endTrajectory);

            // Iterate through each obstacle
            for (Polygon obstacle : obstacles) {
                List<Point> obstaclePoints = obstacle.getPoints();

                // Check each segment of the obstacle
                for (int j = 0; j < obstaclePoints.size(); j++) {
                    Point startObstacle = obstaclePoints.get(j);
                    Point endObstacle = obstaclePoints.get((j + 1) % obstaclePoints.size());
                    System.out.println("  Against obstacle segment: From " + startObstacle.getX() + "," + startObstacle.getY() + " to " + endObstacle.getX() + "," + endObstacle.getY());

                    Straight_segment obstacleSegment = new Straight_segment(startObstacle, endObstacle);

                    // Check if the trajectory segment intersects with the obstacle segment
                    if (trajectorySegment.doIntersect(obstacleSegment)) {
                        System.out.println("Intersection detected");
                        return 1; // An intersection was found
                    }
                }
            }
        }
        System.out.println("No intersection found.");
        return 0; // No intersections were found
    }
}
