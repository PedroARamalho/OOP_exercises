/**
 * Represents a positive point in 2D space
 * @author Jorge Silva a67427
 * @version 2.1 - 29/02/2024
 * @inv all points must be positive at all times
 */

public class Point {
    /**
     * Attributes
     */
    private double x, y;

    /**
     * Point Constructor
     * Checks if both x and y are positive
     * @param x refers abscissa
     * @param y refers ordinate
     */
    public Point(double x, double y) {
        if(x < 0 || y < 0){
            System.out.println("Ponto:vi");
            System.exit(0);
        }
        this.x = x;
        this.y = y;
    }

    /**
     * dist calculates the euclidian distance between two points
     * @param p refers "that" point
     * @return result of euclidian distance between this and p
     */
    public double dist (Point p) {
        double dx = x - p.x;
        double dy = y - p.y;
        return Math.sqrt(dx*dx + dy*dy);
    }

    /**
     * Returns point.x
     * @return abscissa
     */
    public double getX() {
        return x;
    }

    /**
     * Retuns point.y
     * @return ordinate
     */
    public double getY() {
        return y;
    }
}