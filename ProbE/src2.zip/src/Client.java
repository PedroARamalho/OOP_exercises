import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        Trajectory trajectory = new Trajectory();
        for (int i = 0; i < n; i++) {
            trajectory.add(new Point(sc.nextInt(), sc.nextInt()));
        }

        int m = sc.nextInt();
        List<Polygon> obstacles = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            int k = sc.nextInt();
            List<Point> polygonPoints = new ArrayList<>();
            for (int j = 0; j < k; j++) {
                polygonPoints.add(new Point(sc.nextInt(), sc.nextInt()));
            }
            obstacles.add(new Polygon(polygonPoints));
        }

        int result = trajectory.intersects(obstacles);
        System.out.println(result);

        sc.close();
    }
}
